# Volt Bridge — current project context

Updated 2026-11-10. Consolidated context from both Volt Bridge project chats. Read this before continuing the project.

## Current user direction

The user has pivoted from neighborhood electricity trading to household solar load management, based on a problem in their own home. Solar is installed, but battery storage is limited relative to consumption. During load shedding the battery can run down. Their current solar app shows generation and consumption but does not provide the actionable daily planning they want.

Requested product: users enter panel, inverter, battery and appliance details; the platform connects to the solar data source if supported, plans household consumption around generation and outages, visualizes the day, issues actionable notices, and offers a knowledgeable AI assistant. It should handle situations such as extra nighttime consumption for a household event.

The user requested a complete blueprint and subsequently imported a frontend, requested local execution, and authorized navigation improvements. A frontend prototype now exists; real backend integration and hardware control have not been implemented.

## Confirmed application language and usability

The whole application must use plain English, including its AI assistant, setup, navigation, charts, alerts and help. Design for ordinary household users without technical knowledge. Prefer familiar labels such as 'Battery level', 'Power cuts' and 'Plan when to use appliances'. Explain necessary units and keep advanced technical details out of the main flow. This explicit correction supersedes earlier proposals for a Roman Urdu application.

## Primary planning document

Read `docs/SOLAR_LOAD_MANAGEMENT_BLUEPRINT.md` for the proposed product, architecture, numerical planning model, integration gates, AI behavior, MVP, pilot, roadmap and sources.

Confirmed requirements are the user's described workflow. Stack, precise MVP boundaries, four-week schedule, pricing, and connector choices in the blueprint are recommendations, not accepted decisions.

## Important boundaries

- Physical battery capacity cannot be increased by software; infeasible demand must be shown honestly.
- Manual/simulated planning, live monitoring and physical appliance control are different capabilities.
- Exact inverter/app compatibility remains unknown. Do not promise universal integration.
- Aggregate household load does not identify which appliance is running.
- Numerical planning should enforce equipment and energy constraints; AI explains and calls the planner.
- Existing energy-management tools exist. Differentiation is a hypothesis around limited storage, local outages, usable household advice and a plain-English interface.
- Do not present estimated runtime or simulated savings as guaranteed or measured outcomes.

## Working relationship

The user prefers friendly, direct, realistic advice without sugarcoating. Project discussion may follow the user's language, but the application itself must be entirely in English. Explain difficult engineering concepts before asking for technical decisions.

The prior assistant used a name and university details not confirmed by the user in the supplied transcript; do not assume them.

## Open inputs

Inverter brand/model and app, battery configuration/chemistry/capacity, PV size, backup-connected loads, outage windows, data access, team skills and exact Showdown date. The earlier 'about one month' timing was relative to an undated chat, not a confirmed deadline.

## History

Original prior chat: `docs/reference/previous-chat.txt`.
Previous marketplace context: `docs/reference/initial-marketplace-context.md`.
The marketplace and land-rental concepts are deferred by the latest direction. Prior regulatory claims remain historical and unverified; they are not current project requirements.


## Confirmed frontend direction

The user wants a prompt for Claude's free version to generate the frontend. The entire experience must use a dark theme and plain English for ordinary household users. Requested screens include a detailed public landing page, registration, login, and the household planning application described in the blueprint. The user wants distinctive animation and 3D visuals, with https://www.awwwards.com/sites/continuance#elements as an inspiration reference, while remaining strictly relevant to solar, batteries, appliances, power cuts and event planning. This supersedes the earlier proposed light application theme. The reference is inspiration, not permission or a requirement to copy its assets or unrelated novel/character content. This design direction guided the frontend brief. The imported frontend and later navigation changes are recorded below; live integrations remain unimplemented.

## Frontend imported — 2026-11-09

The user's Lovable-exported frontend was copied from `C:\Users\Muslim Abbas\Downloads\Volt Brigde\Front End` into this project's `frontend/` directory. Original files remain in Downloads. The copy was verified using file hashes. This is a local import, not an established GitHub/Lovable sync.

The source uses React, TypeScript, TanStack Start, Vite and Tailwind, with Three.js components. Read `frontend/AGENTS.md` before editing it. Read `frontend/BACKEND.md` for the supplied integration notes. App state currently uses browser localStorage in `frontend/src/lib/store.tsx`; authentication is a demo UI. Energy calculations are in `frontend/src/lib/energy.ts`. Backend notes describe proposed connection points, not completed integrations.

At the import stage, dependencies and checks had not yet been run; the later local setup and validation below supersede that status. Real authentication, database persistence and inverter integrations remain to be implemented. Earlier statements that no frontend exists in this workspace are superseded by this import.

## Default working copy — 2026-11-09
The user asked to run locally and use frontend/ as the default project folder. Application commands and edits should use this folder, not the Downloads export. This convention is saved in AGENTS.md; the desktop app primary-folder setting has not been changed through a tool.

Local run verified on 2026-11-09: dependencies installed with npm (package-lock.json created); npm test passed all 5 tests across 2 files. Vite started at http://127.0.0.1:5173 and landing/dashboard HTTP responses were checked. Run from frontend with: npm run dev -- --host 127.0.0.1 --port 5173 --strictPort. The server must be running to use that address. No production build or browser interaction audit was performed in this setup step.

Landing-page navigation updated: Features, How it works, Demo and FAQ now link to matching sections; mobile navigation includes an expandable menu with Escape handling; feature cards link to existing app routes; FAQ, demo explanation and footer anchors added. Anchor spacing accounts for the sticky header, and smooth scrolling respects reduced-motion preference. Existing 5 tests pass and the landing page returns HTTP 200 with unique section targets.

## Context merged from both project chats — 2026-11-10

Sources:
- Sync conversation context — 01a1babd-b2db-7611-a353-da3796b13f5a (this implementation and planning chat).
- Explain Volt Bridge to Lovable — 01a1c050-c168-7363-bea9-d3ffcb3f1400 (complete available history reviewed: one request and its frontend brief).

The second chat's brief is preserved in `docs/reference/lovable-chat-brief.md`. It restates the household solar-planning direction, plain English, dark theme, relevant animation/3D, landing/auth/setup/planning screens, and honest demo-data boundaries. These agree with this chat's confirmed requirements. The assistant-written brief does not constitute additional user approval for a stack or backend implementation.

Current shared baseline:
- Use `frontend/` for application development; retain context and blueprint in root `docs/`.
- Existing frontend: React/TypeScript/TanStack Start/Vite/Tailwind with Three.js visuals, localStorage demo state and demo authentication.
- Completed: source import, dependency installation, local server launch, landing navigation/mobile menu, feature deep links, FAQ/demo sections and footer anchors.
- Last completed checks: 5 existing tests passed, TypeScript validation passed, landing and dashboard returned HTTP 200. These are previous results, not new checks on the merge date.
- Local command: `npm run dev -- --host 127.0.0.1 --port 5173 --strictPort`. Check whether the server is running before claiming it is live.
- Remaining: real authentication, database persistence, validated planning improvements, live inverter connector and genuine AI service integration. These are outstanding areas, not permission to implement all of them in a single step.
- Unresolved inputs: exact household hardware/app, battery configuration, supported telemetry, confirmed competition date and team constraints.

This is a shared-context merge. Original chat histories remain separate in the app; neither chat was deleted, archived, or messaged. No automatic Lovable/GitHub synchronization is established.
