# Volt Bridge

A proposed household solar energy-planning assistant for homes with limited battery storage and load shedding, starting with the user's home in Karachi.

It aims to turn system and household data into daily load schedules, battery forecasts, actionable alerts and AI-assisted event planning.

- [Current project context](docs/PROJECT_CONTEXT.md)
- [Complete load-management blueprint](docs/SOLAR_LOAD_MANAGEMENT_BLUEPRINT.md)
- [Original previous chat](docs/reference/previous-chat.txt)
- [Earlier marketplace concept](docs/reference/initial-marketplace-context.md)

Status: blueprint and feasibility validation. No application is implemented. Live integration depends on the exact inverter and data access. Earlier electricity-trading and land-rental ideas are deferred.

Product requirement: the entire application and AI assistant use plain English that ordinary household users can understand.

Frontend source is now in `frontend/`. See [backend integration notes](frontend/BACKEND.md). It is a local source import; backend services and live inverter connections are not yet implemented.

Both project chats are consolidated in [shared project context](docs/PROJECT_CONTEXT.md). The second chat's [Lovable brief](docs/reference/lovable-chat-brief.md) is preserved as reference.
