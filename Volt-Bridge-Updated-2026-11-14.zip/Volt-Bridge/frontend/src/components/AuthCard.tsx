import { Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo, DemoBadge } from "@/components/Logo";
import { SceneBackground } from "@/components/three/SceneBackground";
import { useStore } from "@/lib/store";

export function AuthCard({ mode }: { mode: "login" | "register" }) {
  const nav = useNavigate();
  const { update } = useStore();
  const [name, setName] = useState("");
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (mode === "register") {
      update({ userName: name || "My home", setupDone: false });
      nav({ to: "/app/setup" });
    } else nav({ to: "/app/dashboard" });
  };
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <SceneBackground />
      <form onSubmit={submit} className="glass w-full max-w-sm animate-rise rounded-2xl p-7">
        <div className="flex items-center justify-between"><Logo /><DemoBadge label="Demo sign-in" /></div>
        <h1 className="mt-6 text-2xl font-semibold">{mode === "login" ? "Welcome back" : "Create your account"}</h1>
        <div className="mt-6 space-y-4">
          {mode === "register" && (
            <div><Label htmlFor="n">Household name</Label><Input id="n" value={name} onChange={(e) => setName(e.target.value)} placeholder="The Khan home" /></div>
          )}
          <div><Label htmlFor="e">Email</Label><Input id="e" type="email" required placeholder="you@example.com" /></div>
          <div><Label htmlFor="p">Password</Label><Input id="p" type="password" required minLength={6} /></div>
        </div>
        <Button type="submit" className="mt-6 w-full bg-sun">{mode === "login" ? "Log in" : "Continue to setup"}</Button>
        <p className="mt-4 text-center text-sm text-muted-foreground">
          {mode === "login" ? <>New here? <Link to="/register" className="text-primary">Create account</Link></> : <>Have an account? <Link to="/login" className="text-primary">Log in</Link></>}
        </p>
      </form>
    </div>
  );
}
