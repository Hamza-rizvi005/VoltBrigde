import { createFileRoute } from "@tanstack/react-router";
import { Sun, Moon, Sunrise } from "lucide-react";
import { PageTitle, Panel, Tag } from "@/components/app-ui";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/app/planner")({
  head: () => ({ meta: [{ title: "Daily planner — Volt Bridge" }, { name: "description", content: "Suggested appliance times for today." }] }),
  component: Planner,
});

function Planner() {
  const { state } = useStore();
  const flex = state.appliances.filter((a) => a.flexible);
  const slots = [
    { icon: Sunrise, time: "06:00 – 10:00", title: "Morning", note: "Solar is rising. Keep to essentials and let the battery charge.", items: [] as string[] },
    { icon: Sun, time: "10:00 – 15:00", title: "Sunny window", note: "Best time for heavy appliances — the sun covers them.", items: flex.map((a) => a.name) },
    { icon: Moon, time: "15:00 – 23:00", title: "Evening", note: `Protect backup. Keep the battery above ${state.system.minChargePct}% for night cuts.`, items: state.cuts.filter((c) => c.start >= "15:00").map((c) => `Expected cut ${c.start} (${c.durationHours}h)`) },
  ];
  return (
    <>
      <PageTitle title="Daily planner" sub="Suggestions only — you decide when to switch things on." />
      <div className="relative space-y-4 border-l-2 border-dashed border-border pl-6">
        {slots.map((s, i) => (
          <Panel key={s.title} className="relative" >
            <span className="absolute -left-[38px] top-5 grid size-7 place-items-center rounded-full bg-sun text-primary-foreground"><s.icon className="size-3.5" /></span>
            <div className="flex items-center justify-between"><h3 className="font-semibold">{s.title} <span className="ml-2 text-sm font-normal text-muted-foreground">{s.time}</span></h3><Tag kind="estimate" /></div>
            <p className="mt-1 text-sm text-muted-foreground">{s.note}</p>
            {s.items.length > 0 && <ul className="mt-3 flex flex-wrap gap-2">{s.items.map((it) => <li key={it} className="rounded-full bg-secondary px-3 py-1 text-xs" style={{ animationDelay: `${i * 80}ms` }}>{it}</li>)}</ul>}
          </Panel>
        ))}
      </div>
    </>
  );
}
