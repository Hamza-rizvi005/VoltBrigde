import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Send, Sparkles } from "lucide-react";
import { PageTitle, Panel } from "@/components/app-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useStore } from "@/lib/store";
import { backupHours, energyBalance, essentialWatts } from "@/lib/energy";

export const Route = createFileRoute("/app/assistant")({
  head: () => ({ meta: [{ title: "Assistant — Volt Bridge" }, { name: "description", content: "Ask plain-English questions about your home energy." }] }),
  component: Assistant,
});

type Msg = { role: "user" | "bot"; text: string };

function Assistant() {
  const { state } = useStore();
  const [msgs, setMsgs] = useState<Msg[]>([{ role: "bot", text: "Hi! Ask me things like \"Can I run the AC tonight?\" or \"How long will my backup last?\"" }]);
  const [q, setQ] = useState("");

  // Demo replies from local estimates — replace with a real AI call on the backend.
  const answer = (t: string) => {
    const s = t.toLowerCase();
    const bal = energyBalance(state.system, state.appliances);
    if (s.includes("backup") || s.includes("last")) return `Estimated backup for essentials is about ${backupHours(state.system, essentialWatts(state.appliances))} hours. This is an estimate, not a guarantee.`;
    if (s.includes("ac")) return "Run the AC between 11:00 and 14:00 when solar is strongest. At night it may drain the battery below your reserve quickly.";
    if (s.includes("wash") || s.includes("iron") || s.includes("pump")) return "Midday (11:00–14:00) is best for heavy appliances — the sun covers most of it.";
    return bal.exceeds ? `Today's plan uses more than expected energy by ${Math.abs(bal.surplus)} kWh. Try moving flexible appliances to midday.` : `Today looks fine: about ${bal.surplus} kWh spare (estimate).`;
  };
  const send = (e: FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    setMsgs((m) => [...m, { role: "user", text: q }, { role: "bot", text: answer(q) }]);
    setQ("");
  };
  return (
    <>
      <PageTitle title="Assistant" sub="Plain-English answers. Demo replies for now." />
      <Panel className="flex h-[60vh] flex-col">
        <div className="flex-1 space-y-3 overflow-y-auto">
          {msgs.map((m, i) => (
            <div key={i} className={`flex animate-rise ${m.role === "user" ? "justify-end" : ""}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>
                {m.role === "bot" && <Sparkles className="mr-1 inline size-3 text-primary" />}{m.text}
              </div>
            </div>
          ))}
        </div>
        <form onSubmit={send} className="mt-3 flex gap-2">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask about your energy…" />
          <Button type="submit" size="icon" className="bg-sun" aria-label="Send"><Send className="size-4" /></Button>
        </form>
      </Panel>
    </>
  );
}
