import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import { IconAssistant, IconBackupCore, IconCutShield, IconGathering, IconLiveSignal, IconSchedule, IconSolarPlan } from "@/components/icons";
import { Logo, DemoBadge } from "@/components/Logo";
import { useStore } from "@/lib/store";
import { ThemeToggle } from "@/components/ThemeToggle";

export const Route = createFileRoute("/app")({
  head: () => ({
    meta: [
      { title: "My energy — Volt Bridge" },
      { name: "description", content: "Your household solar and battery plan." },
      { property: "og:title", content: "My energy — Volt Bridge" },
      { property: "og:description", content: "Daily plan, appliances, power cuts and assistant." },
    ],
  }),
  component: AppLayout,
});

const nav = [
  { to: "/app/dashboard", label: "Dashboard", icon: IconLiveSignal },
  { to: "/app/planner", label: "Daily planner", icon: IconSchedule },
  { to: "/app/appliances", label: "Appliances", icon: IconBackupCore },
  { to: "/app/power-cuts", label: "Power cuts", icon: IconCutShield },
  { to: "/app/events", label: "Events", icon: IconGathering },
  { to: "/app/assistant", label: "Assistant", icon: IconAssistant },
  { to: "/app/setup", label: "Home setup", icon: IconSolarPlan },
] as const;

function AppLayout() {
  const { state } = useStore();
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="border-b border-sidebar-border bg-sidebar md:sticky md:top-0 md:h-screen md:w-60 md:border-b-0 md:border-r">
        <div className="flex items-center justify-between p-4"><Logo /></div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:pb-0">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="flex shrink-0 items-center gap-3 rounded-lg px-3 py-2 text-sm text-sidebar-foreground/75 transition-colors hover:bg-sidebar-accent"
              activeProps={{ className: "bg-sidebar-accent !text-primary" }}
            >
              <n.icon className="size-5" /> {n.label}
            </Link>
          ))}
          <Link to="/" className="flex shrink-0 items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-sidebar-accent md:mt-6">
            <LogOut className="size-4" /> Log out
          </Link>
        </nav>
      </aside>
      <main className="flex-1">
        <div className="flex items-center justify-between border-b border-border px-6 py-3">
          <p className="text-sm text-muted-foreground">{state.userName}</p>
          <div className="flex items-center gap-3"><DemoBadge /><ThemeToggle /></div>
        </div>
        <div className="mx-auto max-w-5xl p-6"><Outlet /></div>
      </main>
    </div>
  );
}
