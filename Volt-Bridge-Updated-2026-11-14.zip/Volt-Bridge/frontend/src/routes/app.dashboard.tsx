import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { IconBackupCore, IconGathering, IconSchedule, IconSolarPlan } from "@/components/icons";
import { Alert, BatteryGauge, PageTitle, Panel, Stat } from "@/components/app-ui";
import { useStore } from "@/lib/store";
import { backupHours, cutCoverage, energyBalance, essentialWatts, batteryBreakdown } from "@/lib/energy";
import { demoHourly } from "@/lib/demo-data";

export const Route = createFileRoute("/app/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Volt Bridge" }, { name: "description", content: "Today's solar, battery and backup at a glance." }] }),
  component: Dashboard,
});

function Dashboard() {
  const [hours, setHours] = useState(2);
  const [includeFlexible, setIncludeFlexible] = useState(false);
  const { state } = useStore();
  const { system: s, appliances: a, cuts } = state;
  const distribution = batteryBreakdown(s, a.filter((item) => includeFlexible || item.essential), hours);
  const bal = energyBalance(s, a);
  const backup = backupHours(s, essentialWatts(a));
  const cov = cutCoverage(s, a, cuts);
  const max = Math.max(...demoHourly.map((h) => Math.max(h.solar, h.load)));
  return (
    <div className="energy-dashboard">
      <PageTitle title="Today at home" sub="A simple picture of your energy for today." />
      {!state.setupDone && (
        <div className="mb-4"><Alert tone="warn">You're viewing demo values. <Link to="/app/setup" className="font-semibold text-primary underline">Set up your home</Link> for your own plan.</Alert></div>
      )}
      <div className="grid gap-4 md:grid-cols-3">
        <Stat label="Solar today" value={bal.solar} unit="kWh" icon={<IconSolarPlan className="size-5" />} />
        <Stat label="Home use today" value={bal.load} unit="kWh" icon={<IconGathering className="size-5" />} />
        <Stat label="Backup for essentials" value={Number.isFinite(backup) ? `~${backup}` : "—"} unit="hrs" icon={<IconSchedule className="size-5" />} />
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-[220px_1fr]">
        <Panel className="energy-hover text-center">
          <p className="mb-3 flex items-center justify-center gap-2 text-sm text-muted-foreground"><IconBackupCore className="size-5" /> Battery</p>
          <BatteryGauge pct={s.chargePct} reserve={s.minChargePct} />
          <p className="mt-3 text-xs text-muted-foreground">Dashed line = {s.minChargePct}% reserve</p>
        </Panel>
        <Panel>
          <div className="flex items-center justify-between text-sm"><span className="font-semibold">Sun vs. use, by hour</span><span className="text-muted-foreground">Estimate</span></div>
          <div className="mt-5 flex h-48 items-end gap-1.5">
            {demoHourly.map((h, i) => (
              <div key={h.hour} className="group flex flex-1 flex-col items-center gap-1">
                <div className="flex h-40 w-full items-end gap-0.5">
                  <div className="flex-1 rounded-t bg-solar/80 transition-all duration-700" style={{ height: `${(h.solar / max) * 100}%`, transitionDelay: `${i * 30}ms` }} />
                  <div className="flex-1 rounded-t bg-grid/70" style={{ height: `${(h.load / max) * 100}%` }} />
                </div>
                <span className="text-[9px] text-muted-foreground">{i % 3 === 0 ? h.hour : ""}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-4 text-xs text-muted-foreground"><span><span className="mr-1 inline-block size-2 rounded bg-solar" />Solar</span><span><span className="mr-1 inline-block size-2 rounded bg-grid" />Use</span></div>
        </Panel>
      </div>
      <Panel className="energy-hover mt-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold">Where your battery goes</h2>
            <p className="mt-1 text-sm text-muted-foreground">See what your appliances would use during a power cut.</p>
          </div>
          <span className="rounded-full border border-primary/30 px-3 py-1 text-sm text-primary">{distribution.available.toFixed(2)} kWh available</span>
        </div>
        <div className="my-5 flex flex-wrap items-center gap-x-6 gap-y-3">
          <label className="flex items-center gap-3 text-sm">Power cut: {hours} h
            <input type="range" min="0.5" max="8" step="0.5" value={hours} onChange={(event) => setHours(Number(event.target.value))} className="accent-primary" />
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={includeFlexible} onChange={(event) => setIncludeFlexible(event.target.checked)} className="accent-primary" />
            Include all appliances
          </label>
        </div>
        <div className="space-y-2">
          {distribution.items.length === 0 && <p className="text-sm text-muted-foreground">No appliances selected. <Link to="/app/appliances" className="text-primary underline">Manage appliances</Link></p>}
          {distribution.items.map(({ id, name, needed, percent }) => (
            <div key={id} className="battery-usage-row rounded-xl border border-border/60 p-3">
              <div className="mb-2 flex flex-wrap justify-between gap-2 text-sm">
                <span className="font-medium">{name}</span>
                <span className="text-muted-foreground">{needed.toFixed(2)} kWh · {percent === null ? "No battery energy available" : `${Math.round(percent)}% of battery budget`}</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-muted" aria-hidden="true">
                <div className="battery-usage-fill h-full rounded-full bg-primary" style={{ width: `${Math.min(percent ?? (needed > 0 ? 100 : 0), 100)}%` }} />
              </div>
            </div>
          ))}
        </div>
        <p className="mt-4 text-sm font-medium">
          {distribution.shortfall > 0 ? `Estimated shortfall: ${distribution.shortfall.toFixed(2)} kWh` : `Estimated energy left: ${distribution.remaining.toFixed(2)} kWh`}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">Assumes the selected appliances are on backup and run throughout the cut, with no solar or grid power. Your reserve stays out of the available budget.</p>
      </Panel>
      <div className="mt-4 space-y-2">
        {bal.exceeds ? <Alert tone="bad">Planned use is more than estimated solar plus battery today by {Math.abs(bal.surplus)} kWh. Consider moving flexible appliances.</Alert> : <Alert tone="ok">Today looks balanced — about {bal.surplus} kWh spare (estimate).</Alert>}
        {cov.covered ? <Alert tone="ok">Your battery should cover today's expected power cuts for essentials ({cov.needKwh} kWh needed).</Alert> : <Alert tone="warn">Expected cuts may need {cov.needKwh} kWh but only ~{cov.haveKwh} kWh is usable. Save charge before the next expected cut.</Alert>}
        <Alert tone="warn">Best time for heavy appliances: 11:00 – 14:00 while solar is strongest.</Alert>
      </div>
    </div>
  );
}
