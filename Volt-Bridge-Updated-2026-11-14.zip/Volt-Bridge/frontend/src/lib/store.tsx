import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Appliance, PowerCut, System } from "./energy";
import { demoAppliances, demoCuts, demoSystem } from "./demo-data";

type State = {
  userName: string;
  system: System;
  appliances: Appliance[];
  cuts: PowerCut[];
  setupDone: boolean;
};

const initial: State = {
  userName: "Demo household",
  system: demoSystem,
  appliances: demoAppliances,
  cuts: demoCuts,
  setupDone: false,
};

const KEY = "voltbridge-demo";
const Ctx = createContext<{ state: State; update: (p: Partial<State>) => void; reset: () => void } | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(initial);
  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setState({ ...initial, ...JSON.parse(raw) });
    } catch {}
  }, []);
  const update = (p: Partial<State>) =>
    setState((s) => {
      const n = { ...s, ...p };
      localStorage.setItem(KEY, JSON.stringify(n));
      return n;
    });
  const reset = () => {
    localStorage.removeItem(KEY);
    setState(initial);
  };
  return <Ctx.Provider value={{ state, update, reset }}>{children}</Ctx.Provider>;
}

export function useStore() {
  const c = useContext(Ctx);
  if (!c) throw new Error("StoreProvider missing");
  return c;
}
