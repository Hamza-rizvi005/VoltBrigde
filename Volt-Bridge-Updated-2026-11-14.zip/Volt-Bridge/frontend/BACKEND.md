# Volt Bridge — backend notes

Everything below is what exists in this source drop today, and the exact places to
change when you add a real backend.

## What is real today

- **No database, no accounts, no server calls.** Nothing in `src/` talks to a server.
  The only `fetch` in the project is the framework's own SSR entry in `src/server.ts`.
- **All app data lives in the browser.** `src/lib/store.tsx` keeps one state object in
  `localStorage` under the key `voltbridge-demo`.
- **Sign-in and sign-up are screens only.** `/login` and `/register` render
  `src/components/AuthCard.tsx`; they do not create or check an account.

## Data shape (the contract your API should match)

`src/lib/store.tsx` holds:

```ts
type State = {
  userName: string;
  system: System;        // panelKw, sunHours, batteryKwh, minChargePct, inverterKw, chargePct
  appliances: Appliance[]; // id, name, watts, hoursPerDay, essential, flexible
  cuts: PowerCut[];      // id, start (ISO string), durationHours
  setupDone: boolean;
};
```

The types live in `src/lib/energy.ts` and are plain TypeScript — reuse them as your
request/response DTOs.

## Where to swap in the backend

1. **`src/lib/store.tsx`** — the single seam. Replace the `localStorage` read in the
   `useEffect`, the write inside `update()`, and `reset()` with API calls. Every screen
   reads through `useStore()`, so no other file needs to change for basic persistence.
2. **`src/lib/demo-data.ts`** — sample household, appliances and power cuts. Delete once
   the API returns real rows.
3. **`src/lib/energy.ts`** — pure planning maths (daily load, solar estimate, usable
   battery, backup hours, surplus). It has no I/O, so you can port it straight to your
   server, or keep it on the client and only fetch raw rows. It is covered by
   `src/lib/energy.test.ts`.
4. **`src/start.ts`** — add client middleware here if your server functions need a bearer
   token.
5. **`src/routes/`** — one file per screen (`app.dashboard`, `app.appliances`,
   `app.planner`, `app.power-cuts`, `app.events`, `app.setup`, `app.assistant`,
   `app.events`, `login`, `register`, `index`). Add route loaders here for server data.

## Suggested server side (TanStack Start)

- App-internal logic: `createServerFn` from `@tanstack/react-start`.
- Endpoints for other callers: files under `src/routes/api/...`
  (use `src/routes/api/public/...` only for endpoints that must skip site auth, and
  verify the caller inside the handler).
- `process.env.*` is server-only and must be read inside handlers; browser-side config
  uses `import.meta.env.VITE_*`.

## Run it

```bash
bun install        # or npm install
bun run dev        # dev server
bun run test       # vitest — energy maths + routing tests
bun run build      # production build
```

## Not in this drop

- No database schema or migrations.
- No auth provider, tokens, or user records.
- No `.env` — nothing to configure yet.
